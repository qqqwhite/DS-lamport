public class Config {
    boolean isTestingModel = false;
    static final int aggrPort = 4567;
    static final String aggrIP = "127.0.0.1";
    static final int bufferSize = 1024;
    static final String storageFilename = "storage";
}